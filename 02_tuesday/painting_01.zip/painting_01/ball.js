var length = data.length;

// you work goes here
// -----------------------
